const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');// parses incoming bodys like submitting forms you can grab the data
const cors = require('cors');// allows requests from a different domain name
const passport = require('passport');
const mongoose = require('mongoose');
const config = require('./config/database')

// connect to database
mongoose.connect(config.database, {useNewUrlParser: true });


//on connection
mongoose.connection.on('connected', () => {
  console.log('connected to database'+config.database);
});

//on error
mongoose.connection.on('error',(err) => {
  console.log('database error: '+err);
});

// intialiseing the app varible with express
const app = express();

const users = require('./routes/users');


//the port number
const port = 3001;

//cors middleware
app.use(cors());

//set static folder
app.use(express.static(path.join(__dirname, 'public')));

//body parse middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
// passport middleware
app.use(passport.initialize());
app.use(passport.session());

require('./config/passport')(passport);

app.use('/users', users);

// route to the homepage
app.get('/', (req, res) => {
  res.send( 'Invalid Endpoint');
});

// passport middleware

//starts the server
app.listen(port, () => {
  console.log('server started on port' +port);
});
